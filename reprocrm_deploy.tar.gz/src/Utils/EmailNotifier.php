<?php

namespace ReproCRM\Utils;

/**
 * Класс для отправки email уведомлений
 */
class EmailNotifier
{
    private $config;
    
    public function __construct($config = [])
    {
        $this->config = array_merge([
            'smtp_host' => 'localhost',
            'smtp_port' => 587,
            'smtp_username' => '',
            'smtp_password' => '',
            'from_email' => 'noreply@reprosystem.ru',
            'from_name' => 'Система РЕПРО',
            'use_php_mail' => true // Использовать PHP mail() вместо SMTP
        ], $config);
    }
    
    /**
     * Отправка email уведомления
     */
    public function send($to, $subject, $message, $isHtml = true)
    {
        try {
            if ($this->config['use_php_mail']) {
                return $this->sendWithPhpMail($to, $subject, $message, $isHtml);
            } else {
                return $this->sendWithSmtp($to, $subject, $message, $isHtml);
            }
        } catch (\Exception $e) {
            error_log("Email sending error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Отправка с использованием PHP mail()
     */
    private function sendWithPhpMail($to, $subject, $message, $isHtml)
    {
        $headers = [
            'From: ' . $this->config['from_name'] . ' <' . $this->config['from_email'] . '>',
            'Reply-To: ' . $this->config['from_email'],
            'X-Mailer: PHP/' . phpversion(),
            'Content-Type: ' . ($isHtml ? 'text/html; charset=UTF-8' : 'text/plain; charset=UTF-8')
        ];
        
        return mail($to, $subject, $message, implode("\r\n", $headers));
    }
    
    /**
     * Отправка с использованием SMTP (базовая реализация)
     */
    private function sendWithSmtp($to, $subject, $message, $isHtml)
    {
        // Здесь можно добавить SMTP реализацию с использованием PHPMailer или аналогичной библиотеки
        // Пока возвращаем true для демонстрации
        error_log("SMTP email would be sent to: {$to}, subject: {$subject}");
        return true;
    }
    
    /**
     * Отправка уведомления о новом промокоде
     */
    public function sendPromoCodeCreated($doctorEmail, $doctorName, $promoCode)
    {
        $subject = "Ваш промокод готов к использованию";
        $message = $this->getPromoCodeCreatedTemplate($doctorName, $promoCode);
        
        return $this->send($doctorEmail, $subject, $message, true);
    }
    
    /**
     * Отправка уведомления о продажах
     */
    public function sendSalesReport($doctorEmail, $doctorName, $salesData)
    {
        $subject = "Отчет по вашим продажам";
        $message = $this->getSalesReportTemplate($doctorName, $salesData);
        
        return $this->send($doctorEmail, $subject, $message, true);
    }
    
    /**
     * Отправка уведомления администратору
     */
    public function sendAdminNotification($adminEmail, $subject, $message)
    {
        $message = $this->getAdminNotificationTemplate($message);
        
        return $this->send($adminEmail, $subject, $message, true);
    }
    
    /**
     * Шаблон для уведомления о создании промокода
     */
    private function getPromoCodeCreatedTemplate($doctorName, $promoCode)
    {
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #667eea; color: white; padding: 20px; text-align: center; }
                .content { padding: 20px; background: #f9f9f9; }
                .promo-code { background: #fff; border: 2px solid #667eea; padding: 20px; text-align: center; margin: 20px 0; }
                .promo-code h2 { color: #667eea; margin: 0; }
                .footer { padding: 20px; text-align: center; font-size: 12px; color: #666; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>Система РЕПРО</h1>
                </div>
                <div class='content'>
                    <p>Здравствуйте, <strong>{$doctorName}</strong>!</p>
                    <p>Ваш промокод успешно создан и готов к использованию:</p>
                    
                    <div class='promo-code'>
                        <h2>{$promoCode}</h2>
                    </div>
                    
                    <p>Используйте этот промокод для отслеживания ваших продаж в системе.</p>
                    <p>Для входа в систему перейдите по ссылке: <a href='http://localhost:8000/doctor_panel.php'>Система РЕПРО</a></p>
                </div>
                <div class='footer'>
                    <p>Это автоматическое сообщение. Пожалуйста, не отвечайте на него.</p>
                </div>
            </div>
        </body>
        </html>";
    }
    
    /**
     * Шаблон для отчета о продажах
     */
    private function getSalesReportTemplate($doctorName, $salesData)
    {
        $totalSales = count($salesData);
        $totalQuantity = array_sum(array_column($salesData, 'quantity'));
        
        $salesTable = '<table border="1" cellpadding="10" cellspacing="0" style="width: 100%; border-collapse: collapse;">';
        $salesTable .= '<tr style="background: #f0f0f0;"><th>Продукт</th><th>Дата</th><th>Количество</th></tr>';
        
        foreach ($salesData as $sale) {
            $salesTable .= "<tr><td>{$sale['product_name']}</td><td>{$sale['sale_date']}</td><td>{$sale['quantity']}</td></tr>";
        }
        
        $salesTable .= '</table>';
        
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #28a745; color: white; padding: 20px; text-align: center; }
                .content { padding: 20px; background: #f9f9f9; }
                .stats { background: #fff; padding: 15px; margin: 15px 0; border-left: 4px solid #28a745; }
                .footer { padding: 20px; text-align: center; font-size: 12px; color: #666; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>Отчет по продажам</h1>
                </div>
                <div class='content'>
                    <p>Здравствуйте, <strong>{$doctorName}</strong>!</p>
                    <p>Ваш еженедельный отчет по продажам:</p>
                    
                    <div class='stats'>
                        <h3>Статистика:</h3>
                        <p><strong>Всего продаж:</strong> {$totalSales}</p>
                        <p><strong>Общее количество товаров:</strong> {$totalQuantity}</p>
                    </div>
                    
                    <h3>Детализация продаж:</h3>
                    {$salesTable}
                    
                    <p>Для просмотра полной статистики перейдите в систему: <a href='http://localhost:8000/user_dashboard.php'>Дашборд пользователя</a></p>
                </div>
                <div class='footer'>
                    <p>Это автоматическое сообщение. Пожалуйста, не отвечайте на него.</p>
                </div>
            </div>
        </body>
        </html>";
    }
    
    /**
     * Шаблон для уведомлений администратора
     */
    private function getAdminNotificationTemplate($message)
    {
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #dc3545; color: white; padding: 20px; text-align: center; }
                .content { padding: 20px; background: #f9f9f9; }
                .alert { background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; margin: 15px 0; }
                .footer { padding: 20px; text-align: center; font-size: 12px; color: #666; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>Система РЕПРО - Уведомление</h1>
                </div>
                <div class='content'>
                    <div class='alert'>
                        {$message}
                    </div>
                    <p>Для просмотра подробной информации перейдите в административную панель: <a href='http://localhost:8000/admin_working.php'>Админ панель</a></p>
                </div>
                <div class='footer'>
                    <p>Это автоматическое сообщение системы РЕПРО.</p>
                </div>
            </div>
        </body>
        </html>";
    }
    
    /**
     * Проверка конфигурации email
     */
    public function testConfiguration()
    {
        $testEmail = 'test@example.com';
        $subject = 'Тест системы уведомлений';
        $message = '<p>Это тестовое сообщение для проверки работы системы уведомлений.</p>';
        
        try {
            $result = $this->send($testEmail, $subject, $message, true);
            return [
                'success' => $result,
                'message' => $result ? 'Email конфигурация работает корректно' : 'Ошибка отправки email'
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'Ошибка конфигурации: ' . $e->getMessage()
            ];
        }
    }
}
?>
