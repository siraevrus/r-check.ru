<?php

// Проверка авторизации пользователя
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$userEmail = $_SESSION['user_email'] ?? '';
$userLoggedIn = isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true;

// Для обхода авторизации (только для тестирования)
if (isset($_GET['bypass_auth']) && !empty($_GET['email'])) {
    $userEmail = $_GET['email'];
    $userLoggedIn = true;
}

if (!$userLoggedIn || empty($userEmail)) {
    header('Location: /user.php');
    exit;
}

require_once __DIR__ . '/vendor/autoload.php';

use ReproCRM\Config\Config;
Config::load();
$_ENV['DB_TYPE'] = 'sqlite';

// Подключаемся к базе данных
$dbPath = __DIR__ . '/database/reprocrm.db';
$pdo = new PDO("sqlite:" . $dbPath);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Получаем информацию о пользователе
$stmt = $pdo->prepare("
    SELECT 
        u.id,
        u.full_name,
        u.email,
        u.city,
        u.created_at,
        pc.code as promo_code,
        pc.total_sales
    FROM users u
    LEFT JOIN promo_codes pc ON u.promo_code_id = pc.id
    WHERE u.email = ?
");
$stmt->execute([$userEmail]);
$user = $stmt->fetch();

if (!$user) {
    // Если пользователь не найден, перенаправляем на страницу входа
    header('Location: /user_panel.php');
    exit;
}

// Получаем статистику продаж пользователя
$stmt = $pdo->prepare("
    SELECT 
        COUNT(s.id) as total_sales,
        COALESCE(SUM(s.quantity), 0) as total_quantity,
        COUNT(DISTINCT s.product_name) as unique_products
    FROM sales s
    JOIN promo_codes pc ON s.promo_code_id = pc.id
    WHERE pc.code = ?
");
$stmt->execute([$user['promo_code']]);
$salesStats = $stmt->fetch();


?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Дашборд пользователя - Система РЕПРО</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="min-h-screen bg-gray-100">
    <nav class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <h1 class="text-xl font-semibold text-gray-900">Система учета</h1>
                </div>
                <div class="flex items-center space-x-6">
                    <a href="/user_dashboard.php" class="px-3 py-2 rounded-md text-sm font-medium text-gray-600 hover:text-blue-600">
                        Cтатистика
                    </a>
                    <a href="/user_profile_edit.php" class="px-3 py-2 rounded-md text-sm font-medium text-gray-600 hover:text-blue-600">
                        Профиль
                    </a>
                    <a href="/user_logout.php" class="text-gray-500 hover:text-gray-700">
                        Выход
                    </a>
                </div>
            </div>
        </div>
    </nav>
    
    <div class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <!-- Общая сумма продаж -->
        <div class="bg-white shadow rounded-lg mb-6">
            <div class="px-4 py-5 sm:p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h3 class="text-lg leading-6 font-medium text-gray-900">Общая сумма продаж</h3>
                        <p class="text-sm text-gray-500">Из таблицы promo_codes</p>
                    </div>
                    <div class="text-right">
                        <p class="text-3xl font-bold text-green-600">
                            <?= number_format($user['total_sales'] ?? 0, 0, ',', ' ') ?> шт.
                        </p>
                    </div>
                </div>
            </div>
        </div>


    </div>

</body>
</html>
