#!/bin/bash

echo "🛑 Остановка системы..."
docker-compose down
echo "✅ Система остановлена"
